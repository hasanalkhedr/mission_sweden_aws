<?php
return [
    'roles' => [
        'employee' => 'Employé',
        'supervisor' => 'Superieur',
        'hr' => 'RH',
        'sg' => 'SG',
    ]
];
