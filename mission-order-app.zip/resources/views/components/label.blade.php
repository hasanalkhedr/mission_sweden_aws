<label {{$attributes->merge(['class'=>'block tracking-wide text-blue-700 text-xs mb-2']) }}>
    {{$slot}}
</label>
