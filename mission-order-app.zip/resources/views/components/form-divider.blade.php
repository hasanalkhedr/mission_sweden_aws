<hr class="h-0.5 my-1 bg-blue-400 border-0 dark:bg-gray-700" />
<h1 {{ $attributes->merge([ 'class'=>'pb-2 text-md font-bold text-blue-700']) }}>{{ $slot }}</h1>
