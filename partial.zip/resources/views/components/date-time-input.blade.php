<input {{$attributes->merge([
    'class' => 'appearance-none w-2/5 text-gray-700 border border-blue-700 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500 h-10', 'lang' => 'fr'
])}}/>
