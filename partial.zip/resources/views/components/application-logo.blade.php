<img src="{{ Vite::asset('resources/images/logo-IFL.png') }}" {{$attributes}}/>
